# Progress report for Overleaf

Compile main.tex with pdfLaTeX. The report has two pages, 11pt text, single spacing, and one-inch margins.

All required figures are local. No experiment data are needed.
